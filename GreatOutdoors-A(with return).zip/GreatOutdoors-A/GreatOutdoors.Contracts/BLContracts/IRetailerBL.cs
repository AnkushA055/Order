﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface IRetailerBL : IDisposable
    {
        Task<bool> AddRetailerBL(Retailer newRetailer);
        Task<List<Retailer>> GetAllRetailersBL();
        Task<Retailer> GetRetailerByRetailerIDBL(Guid searchRetailerID);
        Task<List<Retailer>> GetRetailersByNameBL(string retailerName);
        Task<Retailer> GetRetailerByEmailBL(string email);
        Task<Retailer> GetRetailerByEmailAndPasswordBL(string email, string password);
        Task<bool> UpdateRetailerBL(Retailer updateRetailer);
        Task<bool> UpdateRetailerPasswordBL(Retailer updateRetailer);
        Task<bool> DeleteRetailerBL(Guid deleteRetailerID);
    }
}


