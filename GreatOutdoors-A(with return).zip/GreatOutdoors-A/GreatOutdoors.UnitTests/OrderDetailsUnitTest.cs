﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreatOutdoors.UnitTests
{
    [TestClass]
    public class OrderDetailsUnitTest
    {
        [TestMethod]
        public async Task AddValidOrderDetailsBL()
        {
            //Arrange
            OrderDetailsBL orderDetailsBL = new OrderDetailsBL();
            OrderDetail orderDetail = new OrderDetail() { OrderID = Guid.NewGuid(), ProductID = Guid.NewGuid(), Quantity=5, UnitPrice=10, TotalPrice=50, AddressID=Guid.NewGuid(), Status=ProductStatus.InCart};
            bool isAdded = false;
            string errorMessage = null;
           
            //Act
            try
            {
                isAdded = await orderDetailsBL.AddOrderDetailsBL(orderDetail);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }


        [TestMethod]
        public async Task ValidGetOrderDetailsByOrderID()
        {
            //Arrange
            OrderDetailsBL orderDetailsBL = new OrderDetailsBL();
            OrderDetail orderDetail = new OrderDetail() { OrderID = Guid.NewGuid(), ProductID = Guid.NewGuid(), Quantity = 5, UnitPrice = 10, TotalPrice = 50, AddressID = Guid.NewGuid(), Status = ProductStatus.InCart };
            bool isAdded = false;
            bool isFetched = false;
            await orderDetailsBL.AddOrderDetailsBL(orderDetail);
            OrderDetail orderDetail1 = new OrderDetail() { OrderID = orderDetail.OrderID, ProductID = Guid.NewGuid(), Quantity = 6, UnitPrice = 10, TotalPrice = 60, AddressID = Guid.NewGuid(), Status = ProductStatus.InCart };
            await orderDetailsBL.AddOrderDetailsBL(orderDetail1);
            string errorMessage = null;

            //Act
            try
            {
                List<OrderDetail> fetchedList = await orderDetailsBL.GetOrderDetailsByOrderIDBL(orderDetail.OrderID);
                int count = fetchedList.Count;

                OrderDetail orderDetail2 = new OrderDetail() { OrderID = orderDetail.OrderID, ProductID = Guid.NewGuid(), Quantity = 7, UnitPrice = 10, TotalPrice = 70, AddressID = Guid.NewGuid(), Status = ProductStatus.InCart };
                await orderDetailsBL.AddOrderDetailsBL(orderDetail2);

                List<OrderDetail> fetchedListAgain = await orderDetailsBL.GetOrderDetailsByOrderIDBL(orderDetail.OrderID);
                int countAgain = fetchedListAgain.Count;

                if (countAgain == count+1)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isFetched, errorMessage);
            }
        }

        [TestMethod]
        public async Task ValidDeleteOrderByOrderDetailID()
        {
            OrderDetailsBL orderDetailBL = new OrderDetailsBL();
            OrderDetail orderDetail = new OrderDetail() { OrderID = Guid.NewGuid() , ProductID = Guid.NewGuid(), Quantity = 7, UnitPrice = 10, TotalPrice = 70, AddressID = Guid.NewGuid(), Status = ProductStatus.InCart };
            bool isDeleted = false;
            bool isAdded = false;
            string errorMessage = null;
            
            isAdded = await orderDetailBL.AddOrderDetailsBL(orderDetail);
            OrderDetail orderDetail1 = new OrderDetail() { OrderID = orderDetail.OrderID, ProductID = Guid.NewGuid(), Quantity = 8, UnitPrice = 10, TotalPrice = 80, AddressID = Guid.NewGuid(), Status = ProductStatus.InCart };
            isAdded = await orderDetailBL.AddOrderDetailsBL(orderDetail1);
            //Act
            try
            {
                List<OrderDetail> fetchedList = await orderDetailBL.GetOrderDetailsByOrderIDBL(orderDetail.OrderID);
                int count = 0;
                foreach (var item in fetchedList)
                {
                    if (item.ProductID == orderDetail.ProductID)
                        count++;

                }
                int countFetchedList = fetchedList.Count;
                await orderDetailBL.DeleteOrderDetailsBL(orderDetail.OrderID,orderDetail.ProductID);
                
                List<OrderDetail> fetchedListAgain = await orderDetailBL.GetOrderDetailsByOrderIDBL(orderDetail.OrderID);
                int countAgain = fetchedListAgain.Count;
                if (countAgain == countFetchedList-count)
                    isDeleted = true;
            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isDeleted, errorMessage);
            }
        }



        [TestMethod]
        public async Task ValidUpdateOrderDetailStatusBL()
        {
            OrderDetailsBL orderDetailBL = new OrderDetailsBL();
            OrderDetail orderDetail = new OrderDetail() { OrderID = Guid.NewGuid(), ProductID = Guid.NewGuid(), Quantity = 7, UnitPrice = 10, TotalPrice = 70, AddressID = Guid.NewGuid(), Status = ProductStatus.InCart };
            bool isUpdated = false;
            bool isAdded = false;
            string errorMessage = null;

            isAdded = await orderDetailBL.AddOrderDetailsBL(orderDetail);
            OrderDetail orderDetail1 = new OrderDetail() { OrderID = orderDetail.OrderID, ProductID = Guid.NewGuid(), Quantity = 8, UnitPrice = 10, TotalPrice = 80, AddressID = Guid.NewGuid(), Status = ProductStatus.InCart };
            isAdded = await orderDetailBL.AddOrderDetailsBL(orderDetail1);
            //Act
            try
            {   
                List<OrderDetail> fetchedList = await orderDetailBL.GetOrderDetailsByOrderIDBL(orderDetail.OrderID);
                List<OrderDetail> fetchedListWithProductID = new List<OrderDetail>();
                int count = 0;
                foreach (var item in fetchedList)
                {
                    if (item.ProductID == orderDetail.ProductID)
                    {
                        fetchedListWithProductID.Add(item);
                        count++;
                    }
                }
                ProductStatus status = ProductStatus.UnderProcessing;
                isUpdated = orderDetailBL.UpdateOrderDetailStatusBL(orderDetail.OrderID, orderDetail.ProductID, status);
                
                
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }





        
    }
}
