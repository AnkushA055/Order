﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Exceptions
{
    /// <summary>
    /// Represents exception in Great Outdoors
    /// </summary>
    public class GreatOutdoorsException : ApplicationException
    {
        //Constructors
        public GreatOutdoorsException() : base()
        {
        }

        public GreatOutdoorsException(string message)
            : base(message)
        {
        }
        public GreatOutdoorsException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }

}
