﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Capgemini.GreatOutdoors.UnitTests
{
    [TestClass]
    public class AddOrderBLTest
    {
        /// <summary>
        /// Add Order to the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task AddValidOrderBL()
        {
            //Arrange
            OrderBL orderBL = new OrderBL();
            Order order = new Order() { TotalQuantity = 5,TotalAmount = 100, AddressID = Guid.NewGuid(), ChannelOfSale = Channel.Online, RetailerID = Guid.NewGuid()};
            bool isAdded = false;
            string errorMessage = null;
            Guid orderDetailID;

            //Act
            try
            {
                (isAdded, orderDetailID) = await orderBL.AddOrderBL(order);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }
                
    }


    [TestClass]
    public class GetOrdersBL
    {
        /// <summary>
        /// Get Orders
        /// </summary>
        [TestMethod]
        public async Task ValidGetAllOrders()
        {
            OrderBL orderBL = new OrderBL();
            Order order = new Order() { TotalQuantity = 5, TotalAmount = 100, AddressID = Guid.NewGuid(), ChannelOfSale = Channel.Online, RetailerID = Guid.NewGuid() };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            Guid orderDetailID;
            (isAdded, orderDetailID) = await orderBL.AddOrderBL(order);
            Order order1 = new Order() { TotalQuantity = 6, TotalAmount = 110, AddressID = Guid.NewGuid(), ChannelOfSale = Channel.Online, RetailerID = Guid.NewGuid() };
            (isAdded, orderDetailID) = await orderBL.AddOrderBL(order1);
            //Act
            try
            {
                List<Order> fetchedList =  await orderBL.GetAllOrdersBL();
                int count = fetchedList.Count;
                Order order2 = new Order() { TotalQuantity = 6, TotalAmount = 110, AddressID = Guid.NewGuid(), ChannelOfSale = Channel.Online, RetailerID = Guid.NewGuid() };
                (isAdded, orderDetailID) = await orderBL.AddOrderBL(order2);
                List<Order> fetchedListAgain = await orderBL.GetAllOrdersBL();
                int countAgain = fetchedListAgain.Count;
                if (countAgain == count + 1)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isFetched, errorMessage);
            }
        }

        /// <summary>
        /// Should raise an error if invalid SalesPerson ID is given
        /// </summary>
        [TestMethod]
        public async Task ValidGetOrderByOrderIDBL()
        {
            OrderBL orderBL = new OrderBL();
            Order order = new Order() { TotalQuantity = 5, TotalAmount = 100, AddressID = Guid.NewGuid(), ChannelOfSale = Channel.Online, RetailerID = Guid.NewGuid() };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            Guid orderDetailID;
            (isAdded, orderDetailID) = await orderBL.AddOrderBL(order);
           
            
            try
            {
                Order fetched = await orderBL.GetOrderByOrderIDBL(orderDetailID);
                if (fetched.OrderID == orderDetailID)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isFetched = false ;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isFetched, errorMessage);
            }
        }



        [TestMethod]
        public async Task InvalidGetOrderByOrderIDBL()
        {
            OrderBL orderBL = new OrderBL();
            Order order = new Order() { TotalQuantity = 5, TotalAmount = 100, AddressID = Guid.NewGuid(), ChannelOfSale = Channel.Online, RetailerID = Guid.NewGuid() };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            Guid orderDetailID;
            (isAdded, orderDetailID) = await orderBL.AddOrderBL(order);
            Guid orderDetailIDNew = Guid.NewGuid();

            try
            {
                Order fetched = await orderBL.GetOrderByOrderIDBL(orderDetailIDNew);
                if (fetched.OrderID == null)
                    isFetched = false;
            }
            catch (Exception ex)
            {
                isFetched = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isFetched, errorMessage);
            }
        }

        [TestMethod]
        public async Task InvalidGetOrderByRetailerIDBL()
        {
            OrderBL orderBL = new OrderBL();

            Order order = new Order() { TotalQuantity = 5, TotalAmount = 100, AddressID = Guid.NewGuid(), ChannelOfSale = Channel.Online, RetailerID = Guid.NewGuid() };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            Guid orderDetailID;
            (isAdded, orderDetailID) = await orderBL.AddOrderBL(order);
            
            try
            {
                List<Order> fetched = await orderBL.GetOrderByRetailerIDBL(order.RetailerID);
                if (fetched[0].RetailerID == order.RetailerID)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isFetched, errorMessage);
            }
        }





    }

    [TestClass]
    public class GetSalesPersonByNameBLTest
    {
        /// <summary>
        /// Get SalesPerson if given name is valid
        /// </summary>
        [TestMethod]
        public async Task ValidSalesPersonName()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "Scott", SalesPersonMobile = "9876543210", Password = "Scott123#", Email = "scott@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);
            bool isValid = false;
            string errorMessage = null;

            //Act
            try
            {
                List<SalesPerson> salesPeople = new List<SalesPerson>();
                if ((salesPeople = (await salesPersonBL.GetSalesPersonsByNameBL(salesPerson.SalesPersonName))) != null)
                    isValid = true;
            }
            catch (Exception ex)
            {
                isValid = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isValid, errorMessage);
            }
        }

        /// <summary>
        /// Should raise an error if invalid SalesPerson Name is given
        /// </summary>
        [TestMethod]
        public async Task InvalidSalesPersonName()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            string invalidName = "io";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                List<SalesPerson> salesPeople = new List<SalesPerson>();
                if ((salesPeople = (await salesPersonBL.GetSalesPersonsByNameBL(invalidName))) == null)
                    isValid = false;
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }


        /// <summary>
        /// Should raise an error if SalesPerson Name is null
        /// </summary>
        [TestMethod]
        public async Task SalesPersonNameCannotBeNull()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            string invalidName = null;
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                List<SalesPerson> salesPeople = new List<SalesPerson>();
                if ((salesPeople = (await salesPersonBL.GetSalesPersonsByNameBL(invalidName))) == null)
                    isValid = false;
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }

    }

    [TestClass]
    public class GetSalesPersonByEmailBLTest
    {
        /// <summary>
        /// Get SalesPerson if given email is valid
        /// </summary>
        [TestMethod]
        public async Task ValidSalesPersonEmail()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "Scott", SalesPersonMobile = "9876543210", Password = "Scott123#", Email = "scott@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);
            bool isValid = false;
            string errorMessage = null;

            //Act
            try
            {
                if (salesPerson.Equals((await salesPersonBL.GetSalesPersonByEmailBL(salesPerson.Email))))
                    isValid = true;
            }
            catch (Exception ex)
            {
                isValid = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isValid, errorMessage);
            }
        }

        /// <summary>
        /// Should raise an error if given email doesn't exist
        /// </summary>
        [TestMethod]
        public async Task SalesPersonEmailDoesNotExist()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            string invalidEmail = "io@abc.com";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                SalesPerson salesPerson = new SalesPerson();
                if ((salesPerson = (await salesPersonBL.GetSalesPersonByEmailBL(invalidEmail))) == null)
                    isValid = false;
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }


        /// <summary>
        /// Should raise an error if SalesPerson Email is in invalid format
        /// </summary>
        [TestMethod]
        public async Task SalesPersonEmailRegExp()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            string invalidEmail = "abc";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                SalesPerson salesPerson = new SalesPerson();
                if ((salesPerson = (await salesPersonBL.GetSalesPersonByEmailBL(invalidEmail))) == null)
                    isValid = false;
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }

    }

    [TestClass]
    public class GetSalesPersonByEmailAndPasswordBLTest
    {
        /// <summary>
        /// Get SalesPerson if given email and password are valid
        /// </summary>
        [TestMethod]
        public async Task ValidSalesPersonEmailAndPassword()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "Scott", SalesPersonMobile = "9876543210", Password = "Scott123", Email = "scott@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);
            bool isValid = false;
            string errorMessage = null;

            //Act
            try
            {
                if (salesPerson.Equals((await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(salesPerson.Email, salesPerson.Password))))
                    isValid = true;
            }
            catch (Exception ex)
            {
                isValid = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isValid, errorMessage);
            }
        }

        /// <summary>
        /// Should raise an error if given email is correct but password is incorrect
        /// </summary>
        [TestMethod]
        public async Task SalesPersonEmailCorrectPasswordIncorrect()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            string invalidPassword = "abc2com";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                SalesPerson salesPerson = new SalesPerson();
                if ((salesPerson = (await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(salesPerson.Email, invalidPassword))) == null)
                    isValid = false;
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }


        /// <summary>
        /// Should raise an error if SalesPerson's email is incorrect and password is correct
        /// </summary>
        [TestMethod]
        public async Task SalesPersonEmailIncorrectPasswordCorrect()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "Scott", SalesPersonMobile = "9876543210", Password = "Scott123#", Email = "scott@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);
            string invalidEmail = "abc";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                if ((salesPerson = (await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(invalidEmail, salesPerson.Password))) == null)
                    isValid = false;
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }

        /// <summary>
        /// Should raise an error if SalesPerson's email is incorrect and password is correct
        /// </summary>
        [TestMethod]
        public async Task SalesPersonEmailIncorrectPasswordIncorrect()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            string invalidEmail = "abc";
            string invalidPassword = "8888";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                SalesPerson salesPerson = new SalesPerson();
                if ((salesPerson = (await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(invalidEmail, invalidPassword))) == null)
                    isValid = false;
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }

    }

    [TestClass]
    public class UpdateSalesPersonBLTest
    {
        /// <summary>
        /// Update SalesPerson's details if given name,email and mobile are valid
        /// </summary>
        [TestMethod]
        public async Task ValidSalesPersonDetails()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "John", SalesPersonMobile = "9876543210", Password = "Scott123", Email = "john@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);

            salesPerson.SalesPersonName = "John";
            salesPerson.Email = "john@greatoutdoors.com";
            salesPerson.SalesPersonMobile = "8897476406";

            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await salesPersonBL.UpdateSalesPersonBL(salesPerson);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }



    }

    [TestClass]
    public class UpdateSalesPersonPasswordBLTest
    {
        /// <summary>
        /// Update SalesPerson's password if given password is valid
        /// </summary>
        [TestMethod]
        public async Task ValidSalesPersonPassword()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "John", SalesPersonMobile = "9876543210", Password = "Scott123", Email = "john@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);

            salesPerson.Password = "John123";

            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await salesPersonBL.UpdateSalesPersonPasswordBL(salesPerson);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }

        /// <summary>
        ///SAles person password should follow given format
        /// </summary>
        [TestMethod]
        public async Task InvalidSalesPersonPassword()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "John", SalesPersonMobile = "9876543210", Password = "Scott123", Email = "john@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);

            salesPerson.Password = "John";

            bool isUpdated = true;
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await salesPersonBL.UpdateSalesPersonPasswordBL(salesPerson);
            }
            catch (Exception ex)
            {
                isUpdated = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }



    }

    [TestClass]
    public class DeleteSalesPersonBLTest
    {
        /// <summary>
        /// Delete SalesPerson if given ID is valid
        /// </summary>
        [TestMethod]
        public async Task ValidSalesPersonID()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = new SalesPerson() { SalesPersonName = "Scott", SalesPersonMobile = "9876543210", Password = "Scott123#", Email = "scott@gmail.com" };
            await salesPersonBL.AddSalesPersonBL(salesPerson);
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                isDeleted = await salesPersonBL.DeleteSalesPersonBL(salesPerson.SalesPersonID);
            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isDeleted, errorMessage);
            }
        }

        /// <summary>
        /// Should raise an error if invalid SalesPerson ID is given
        /// </summary>
        [TestMethod]
        public async Task InvalidSalesPersonID()
        {
            //Arrange
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            Guid invalidID = new Guid();
            bool isDeleted = true;
            string errorMessage = null;

            //Act
            try
            {
                isDeleted = await salesPersonBL.DeleteSalesPersonBL(invalidID);
            }
            catch (Exception ex)
            {
                isDeleted = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isDeleted, errorMessage);
            }
        }

    }
}
